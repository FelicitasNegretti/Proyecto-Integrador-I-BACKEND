# Ejemplos en formato JSON

Ejemplos en formato JSON para descargar e incorporar a MongoDB.

* Productos de computación
* Productos electrónicos
* Frutas y verduras
* Mobiliario de hogar y oficina
* Prendas de vestir
* Productos de supermercado

